namespace Classes;


public class Danca : Gastos
{

     public Danca(string Cliente, decimal ValorInicial) : base(Cliente, ValorInicial)
     {       
     }
       public override void ExecutarTransacoesdeFimdeMes()
         {
             decimal Acrescer = ValorAcumulado * 0.02m;
         AtualizarValor(Acrescer, DateTime.Now, "Margem de Segurança para Dança");
         }
}