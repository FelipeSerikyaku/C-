namespace Classes;
public class Gastos
{
    
        public string Cliente { get; set; }
        public decimal ValorAcumulado
    {
    get
    {
        decimal saldo = 0m;
        foreach (var item in todasTransacoes)
        {
            saldo += item.Valor;
        }

        return saldo;
    }
    }
 public Gastos(string Cliente, decimal ValorInicial)
    {
        this.Cliente = Cliente;
        AtualizarValor(0, DateTime.Now, "Valor Inicial");
    }
  private List<Transacao> todasTransacoes = new List<Transacao>();
    public void AtualizarValor(decimal quantia, DateTime data, string nota)
    {
   
    var saque = new Transacao(quantia, data, nota);
    todasTransacoes.Add(saque);
    }

    public string ObterHistoricodeConta()
    {
    var relatorio = new System.Text.StringBuilder();

    decimal saldo = 0m;
    relatorio.AppendLine("Data           Valor  Valor Acumulado     Descrição");
    foreach (var item in todasTransacoes)
    {
        saldo += item.Valor;
        relatorio.AppendLine($"{item.Data.ToShortDateString(), -10}{item.Valor, 10}{saldo, 17} {"   "} {item.Descricao}");
    }

    return relatorio.ToString();

    
    }
 public virtual void ExecutarTransacoesdeFimdeMes() { }
}