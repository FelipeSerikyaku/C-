namespace Classes;


public class Judo : Gastos
{
     private readonly decimal _bonusJudo = -50m;
     public Judo(string Cliente, decimal ValorInicial, decimal bonusJudo = 50m) : base(Cliente, ValorInicial)  
     => _bonusJudo = bonusJudo;
     
       public override void ExecutarTransacoesdeFimdeMes()
         {
             decimal Acrescer = ValorAcumulado * 0.02m;
         AtualizarValor(Acrescer, DateTime.Now, "Margem de Segurança para Judõ");
         if (_bonusJudo != 0)
         {
            AtualizarValor(-_bonusJudo, DateTime.Now, "Bonus Judo");
         }
         }
}