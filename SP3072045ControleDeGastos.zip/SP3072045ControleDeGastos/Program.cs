﻿using Classes;

var conta = new Natacao("Renato Fernandez", 0m);

conta.AtualizarValor(20, DateTime.Now, "Café");
conta.AtualizarValor(50, DateTime.Now, "Compra de Mantimentos");
conta.ExecutarTransacoesdeFimdeMes();
Console.WriteLine(conta.ObterHistoricodeConta());

var conta2 = new Danca ("André rodriguez", 0m);
conta2.AtualizarValor(100, DateTime.Now, "Agasalho");
conta2.AtualizarValor(50, DateTime.Now, "Calça");
conta2.AtualizarValor(250, DateTime.Now, "Terno");
conta2.ExecutarTransacoesdeFimdeMes();
Console.WriteLine(conta2.ObterHistoricodeConta());


var conta3 = new Judo("Pedro Pascal", 0m, 0m);
conta3.AtualizarValor(200, DateTime.Now, "Cinema");
conta3.AtualizarValor(0.7m, DateTime.Now, "feijão");
conta3.ExecutarTransacoesdeFimdeMes();
conta3.AtualizarValor(-50, DateTime.Now, "Bonus Para Judo");
Console.WriteLine(conta3.ObterHistoricodeConta());


var conta4 = new Ingles ("Larapio gomez", 0m);
conta4.AtualizarValor(1000, DateTime.Now, "Linguagem C#");
conta4.ExecutarTransacoesdeFimdeMes();
Console.WriteLine(conta4.ObterHistoricodeConta());