namespace Classes;

public class Transacao 
{
    public decimal Valor { get; set; }
    public DateTime Data { get; }
    public string Descricao { get; }

    public Transacao(decimal Valor, DateTime data, string Descricao)
    {
        
        this.Valor = Valor;
        this.Data = data;
        this.Descricao = Descricao;
    }
}